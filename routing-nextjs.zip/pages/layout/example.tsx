import Layout from "./layout";

export default function Example() {
    return (
        <Layout>
        <div>
            Example of Layout Usage
        </div>
        </Layout>
    )
}